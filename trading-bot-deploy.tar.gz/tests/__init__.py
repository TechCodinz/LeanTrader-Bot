# Minimal test package initializer
__all__ = ["smoke_test"]
